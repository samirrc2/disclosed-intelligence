# Human validation coding kit — Disclosed Intelligence

This kit lets one or two human experts produce a **human gold-standard** validation of the
AI-disclosure classifier, addressing the one reviewer item that cannot be done by a language
model. Everything is prepared; a coder only needs to read excerpts and enter 0/1.

## Files
- `coding_sheet_BLINDED.csv` — what the coder(s) fill in. Columns: `row_id`, `excerpt`, and blank
  `a,b,c,d,e,notes`. Rows are shuffled; **no firm names, CRDs, or machine labels are shown.**
- `CODING_RUBRIC.md` — the exact five-label rubric to apply (identical to the instrument used in the study).
- `HIDDEN_KEY.csv` — maps each `row_id` to the firm CRD, the primary classifier's labels (`m_*`),
  and the LLM independent re-coding (`llm_ind_*`). **Do not open this until coding is finished.**
- `score_human_coding.py` — scores the classifier against the human codes once coding is done.

## Procedure (recommended: two coders)
1. Give each coder a copy of `coding_sheet_BLINDED.csv` and `CODING_RUBRIC.md`. Coders work
   **independently** and do not see the key or each other's sheets.
2. For each row, read the excerpt and enter `1` or `0` in `a,b,c,d,e` per the rubric. A label is `1`
   only if a verbatim phrase in the excerpt supports it (about the filing firm's own practices). If
   there is no qualifying AI/technology content, all five are `0`. Use `notes` for edge cases.
3. Compute inter-coder reliability (Cohen's κ per label) between the two completed sheets, then
   **adjudicate disagreements by discussion** to produce one consensus sheet, `coding_sheet_HUMAN.csv`
   (same columns).
4. Run `python score_human_coding.py coding_sheet_HUMAN.csv` to score the primary classifier against
   the human consensus. It reports design-weighted precision, recall, F1, Cohen's κ, and PABAK per
   label and for any-use, using the same two-phase (verification-sample) weights as the paper, and it
   also reports human-vs-LLM-independent agreement so you can see how the human standard compares to
   the cross-family LLM re-coding already in the paper.

## Sampling note
This kit uses the 180-brochure verification sample already analyzed in the paper (all machine-positive
brochures + a random sample of machine-negatives). Metrics are design-weighted to the classified
population. If a reviewer prefers a simple random sample, draw ~100 rows uniformly and the same script
scores them (set `--srs` to skip the two-phase weights).
