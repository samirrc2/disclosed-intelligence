"""
score_human_coding.py — score the primary classifier against a completed HUMAN coding sheet.

Usage:
    python score_human_coding.py coding_sheet_HUMAN.csv           # design-weighted (default)
    python score_human_coding.py coding_sheet_HUMAN.csv --srs     # unweighted (simple random sample)

Reads HIDDEN_KEY.csv (must be in the same folder). Reports, for the primary classifier (m_*) with
the human consensus as reference: precision, recall, F1, Cohen's kappa, PABAK per label and for
any-use (a OR b OR e). Design weights: model-positive brochures (any label) are a census (weight 1);
model-negative brochures carry weight 265/57 = 4.649 (the two-phase verification design in the paper).
Also prints human-vs-LLM-independent agreement for context.
"""
import csv, sys, math

WNEG = 265 / 57  # two-phase weight for model-negative stratum


def load(path):
    return {r["row_id"]: r for r in csv.DictReader(open(path))}


def metrics(pairs):  # pairs: list of (model, human, weight)
    tp = fp = fn = tn = 0.0
    for m, h, w in pairs:
        if m and h: tp += w
        elif m and not h: fp += w
        elif not m and h: fn += w
        else: tn += w
    n = tp + fp + fn + tn
    prec = tp / (tp + fp) if (tp + fp) else float("nan")
    rec = tp / (tp + fn) if (tp + fn) else float("nan")
    f1 = 2 * prec * rec / (prec + rec) if (prec and rec) else float("nan")
    po = (tp + tn) / n
    pe = ((tp + fp) / n) * ((tp + fn) / n) + ((fn + tn) / n) * ((fp + tn) / n)
    k = (po - pe) / (1 - pe) if (1 - pe) else float("nan")
    return prec, rec, f1, k, 2 * po - 1


def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    srs = "--srs" in sys.argv
    human = load([a for a in sys.argv[1:] if not a.startswith("--")][0])
    key = load("HIDDEN_KEY.csv")
    labels = list("abcde")

    def w_of(rid):
        if srs: return 1.0
        mpos = any(int(key[rid][f"m_{L}"]) for L in labels)
        return 1.0 if mpos else WNEG

    print(f"n = {len(human)} rows   ({'unweighted (SRS)' if srs else 'design-weighted (two-phase)'})\n")
    print(f"{'label':10}{'prec':>8}{'rec':>8}{'F1':>8}{'kappa':>8}{'PABAK':>8}")
    for L in labels + ["any"]:
        pairs = []
        for rid, hrow in human.items():
            k = key[rid]
            if L == "any":
                m = 1 if any(int(k[f"m_{x}"]) for x in ("a", "b", "e")) else 0
                h = 1 if any(int(hrow.get(x, 0) or 0) for x in ("a", "b", "e")) else 0
            else:
                m = int(k[f"m_{L}"]); h = int(hrow.get(L, 0) or 0)
            pairs.append((m, h, w_of(rid)))
        pr, rc, f1, kp, pb = metrics(pairs)
        print(f"{L:10}{pr:8.3f}{rc:8.3f}{f1:8.3f}{kp:8.3f}{pb:8.3f}")

    # human vs LLM-independent (context)
    print("\nHuman vs. LLM independent re-coding (Cohen's kappa, any-use):")
    pairs = []
    for rid, hrow in human.items():
        k = key[rid]
        if k.get("llm_ind_a", "") == "": continue
        li = 1 if any(int(k[f"llm_ind_{x}"]) for x in ("a", "b", "e")) else 0
        h = 1 if any(int(hrow.get(x, 0) or 0) for x in ("a", "b", "e")) else 0
        pairs.append((li, h, w_of(rid)))
    if pairs:
        _, _, _, kp, _ = metrics(pairs)
        print(f"  any-use kappa = {kp:.3f}  (n = {len(pairs)})")


if __name__ == "__main__":
    main()
